import jakarta.validation.constraints.*;

public class BloodRequestDto {

    @NotBlank
    private String patientName;

    @NotBlank
    private String hospital;

    @NotBlank
    private String bloodGroup;

    @NotNull
    @Min(1)
    private Integer units;

    @NotBlank
    private String city;

    @NotBlank
    private String urgency;

    @NotBlank
    private String contact;

    // getters and setters
}